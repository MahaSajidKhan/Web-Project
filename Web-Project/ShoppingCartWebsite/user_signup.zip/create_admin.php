<?php
// create_admin.php disabled by site administrator.
// To prevent UI-based admin creation, this file now redirects to the admin login page.
header('Location: admin_login.php');
exit();
?>
