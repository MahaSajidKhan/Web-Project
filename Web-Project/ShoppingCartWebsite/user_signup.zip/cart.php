<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <h2>Your Cart</h2>

    <?php
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<p>Your cart is empty.</p>";
    } else {
        echo "<table>
                <tr>
                    <td>Product</td>
                    <th>Price (PKR)</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>";

        $grand_total = 0;



        foreach ($_SESSION['cart'] as $id => $item) {
            $total = $item['price'] * $item['quantity'];
            $grand_total += $total;

                echo "                <tr>
                        <td>".$item['name']."</td>
                        <td>".$item['price']."</td>
                        <td>
                            <div style='display:flex; align-items:center; gap:8px;'>
                                <form method='POST' action='update_cart.php' style='display:inline; margin:0;'>
                                    <input type='hidden' name='id' value='$id'>
                                    <input type='hidden' name='action' value='dec'>
                                    <button type='submit' class='btn-qty' title='Decrease'>−</button>
                                </form>
                                <div style='min-width:36px; text-align:center; font-weight:700;'>".$item['quantity']."</div>
                                <form method='POST' action='update_cart.php' style='display:inline; margin:0;'>
                                    <input type='hidden' name='id' value='$id'>
                                    <input type='hidden' name='action' value='inc'>
                                    <button type='submit' class='btn-qty' title='Increase'>+</button>
                                </form>
                            </div>
                        </td>
                        <td>".$total."</td>
                        <td><a class='btn-primary-custom' href='remove_from_cart.php?id=$id'>Remove</a></td>
                    </tr>
                ";
        }

        echo "<tr>
                <th colspan='3'>Grand Total</th>
                <th colspan='2'>$grand_total PKR</th>
              </tr>";

        echo "</table>";
        // After closing the table tag (after echo "</table>";)
echo "<div style='text-align:center; margin-top:20px;'>
                <a href='checkout.php' class='btn-primary-custom'>Proceed to Checkout</a>
            </div>";

    }
    ?>
</div>

</body>
</html>
